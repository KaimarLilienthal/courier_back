# courier_back

FUJITSU trial task for Java programming developers

The objective of the trial task is to assess Java programming skills, selecting
appropriate tools for completing the task, OOP skills, and application design skills,
including object model design, working with API-s, and documenting the code.

Technologies to use
• Java
• Spring framework
• H2 database
