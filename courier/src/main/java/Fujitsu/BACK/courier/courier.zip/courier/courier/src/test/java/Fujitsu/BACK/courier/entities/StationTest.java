package Fujitsu.BACK.courier.entities;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StationTest {

    @Test
    void getId() {
    }

    @Test
    void getStationName() {
    }

    @Test
    void getWmoCode() {
    }

    @Test
    void getAitTemperature() {
    }

    @Test
    void getWindSpeed() {
    }

    @Test
    void getWeatherPhenomenon() {
    }

    @Test
    void getTimestamp() {
    }

    @Test
    void setId() {
    }

    @Test
    void setStationName() {
    }

    @Test
    void setWmoCode() {
    }

    @Test
    void setAitTemperature() {
    }

    @Test
    void setWindSpeed() {
    }

    @Test
    void setWeatherPhenomenon() {
    }

    @Test
    void setTimestamp() {
    }
}